package com.uninabiogardenoo65.dao;

import com.uninabiogardenoo65.controller.Controller;

public class ProprietarioDAO {

    private Controller controller;

    public ProprietarioDAO(Controller controller){
        this.controller = controller;
    }



}

package com.uninabiogardenoo65.enums;

public enum Qualita {
	Eccellente, 
	Ottima,
	Media,
	Scadente,
	Danneggiata
}

package com.uninabiogardenoo65.enums;

public enum Stagione {
	Inverno,
	Estate,
	Primavera,
	Autunno
}

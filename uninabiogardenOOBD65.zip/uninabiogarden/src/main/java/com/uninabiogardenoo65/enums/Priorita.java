package com.uninabiogardenoo65.enums;

public enum Priorita {
	Alta,
	Media,
	Bassa
}

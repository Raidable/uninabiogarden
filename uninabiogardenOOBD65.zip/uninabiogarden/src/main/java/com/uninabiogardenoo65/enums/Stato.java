package com.uninabiogardenoo65.enums;

public enum Stato {
	Sospeso,
	Finito,
	InCorso,
	InStallo,
	NonConcluso
}
